// Copyright 2019-2021 @axia-js/extension authors & contributors
// SPDX-License-Identifier: Apache-2.0

import { createView, Popup } from '@axia-js/extension-ui';

createView(Popup);
