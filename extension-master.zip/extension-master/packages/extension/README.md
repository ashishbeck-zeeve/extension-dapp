# @axia-js/extension

A signing extension
