// Copyright 2019-2021 @axia-js/extension-ui authors & contributors
// SPDX-License-Identifier: Apache-2.0

// import { EnzymeAdapter } from 'enzyme';

// declare module '@wojtekmaj/enzyme-adapter-react-17' {
//   export = EnzymeAdapter;
// }

declare module '@wojtekmaj/enzyme-adapter-react-17';
