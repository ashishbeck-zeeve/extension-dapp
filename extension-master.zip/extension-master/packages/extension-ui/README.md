# @axia-js/extension-ui

UI for the `@axia-js/extension`
