# @axia-js/extension-metamask-compat

An optional metamask-compatible layer
