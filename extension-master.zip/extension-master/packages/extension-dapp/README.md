# @axia-js/extension-dapp

Documentation available [in the axia-js doc](https://axia.js.org/docs/extension).
