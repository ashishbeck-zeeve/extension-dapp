// Copyright 2019-2021 @axia-js/extension authors & contributors
// SPDX-License-Identifier: Apache-2.0

module.exports = require('@axia-js/dev/config/prettier.cjs');
