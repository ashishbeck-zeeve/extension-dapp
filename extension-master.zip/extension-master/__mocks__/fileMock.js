// Copyright 2019-2020 @axia-js/extension authors & contributors
// SPDX-License-Identifier: Apache-2.0

// eslint-disable-line
module.exports = '';
